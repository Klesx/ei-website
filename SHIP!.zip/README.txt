fILES TO UPLOAD AND HOW:


Upload:

All HTML

Stylesheet.css (inside CSS folder by itself)

Fonts folder
img folder
js folder

